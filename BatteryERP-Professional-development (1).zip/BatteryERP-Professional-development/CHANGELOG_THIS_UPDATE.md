# Changelog — Usability, Audio & POS Update

## Fixed
- **Scrolling bug on Settings and other long pages.** Root cause: the
  Settings page (and Dashboard Home) were *each* their own
  `CTkScrollableFrame`, nested inside the main content area - which
  had also just been made scrollable. A scrollable-frame-inside-a-
  scrollable-frame is a known source of "can't reach the bottom"
  bugs (the inner one's scroll region doesn't compute correctly
  against an outer one that's also trying to manage scrolling).
  Fixed by making the **main dashboard content area** the single
  source of scrolling, and converting Settings/Dashboard Home back to
  plain frames. Every page - current and future - now scrolls
  correctly without needing to think about it individually.

## Responsiveness
- The main window and the login window now size themselves off the
  actual screen resolution (capped at a sensible maximum) instead of
  a fixed 1400x800/980x650, and center themselves. On smaller/laptop
  screens (≤1366×768) the app opens maximized automatically.
- Reduced minimum window size to 1000×600 (login: 760×560) - small
  enough to avoid clipping on compact displays, large enough that
  nothing important disappears.
- Note: this covers the "doesn't get clipped/hidden, scales with
  the screen and with maximize/restore" behavior that was reported.
  A full fluid reflow (e.g. the Purchase page's wide rows
  rearranging into fewer columns on very narrow windows) is a
  larger, separate layout redesign - happy to scope that next if
  it's still needed in practice.

## Audio
- Your `om_namo_venkateshaya.mp3` is now the app's default audio,
  wired in at `assets/splash/splash_audio.mp3`.
- It starts on the loading screen and **keeps playing smoothly into
  the dashboard** (no restart/click) via a new `audio_service`, at a
  comfortable background volume, looping continuously.
- **🔊/🔇 speaker icon** in the header's top-right corner mutes/
  unmutes instantly and remembers your choice for next time the app
  opens (stored in Settings, survives restarts).

## POS Terminal Integration (Sales)
- Payment modes **UPI / Credit Card / Debit Card / QR Code** now go
  through a POS payment step instead of saving immediately; **Cash /
  Bank Transfer / Credit** save exactly as before.
- On approval: the sale is saved, stock is decreased, the invoice is
  recorded as paid, and the invoice **prints automatically** - no
  extra clicks.
- On decline/cancel: **nothing is saved** (no stock change, no
  invoice), and you get a clear message with a **Retry** option.
- Every attempt (approved, declined, or cancelled) is logged to a
  new `pos_transactions` table with transaction ID, approval code,
  reference number, payment mode, provider, and status - visible
  under **Reports → POS Transactions**.
- **Built as a modular provider system**
  (`services/pos/base_provider.py`): a real terminal SDK (Pine Labs,
  Razorpay POS, PayTM, etc.) plugs in as one new class implementing
  `charge()` and gets registered in `services/pos/manager.py` - the
  Sales page code doesn't change when that happens.
- **Honesty note:** since no specific POS hardware/SDK was specified,
  the active provider today is a *simulator* (`mock_provider.py`).
  It runs the full real flow (connect → charge → approve/decline/
  cancel → transaction record) but doesn't move real money - the
  "approve/decline" buttons in the payment popup stand in for what a
  real terminal would report on its own. Let me know which POS
  system Kanakadurga Enterprises will actually use and I'll wire up
  the real provider against the same interface.

## Verified this session
- Duplicate-prevention, supplier/product/customer save-update flows
  from prior updates re-tested and still passing after these changes.
- Audio mute/unmute persistence tested against a live database
  (survives a simulated "restart").
- Full POS flow tested end-to-end at the service layer: charge →
  approve → transaction recorded → sale saved → appears correctly in
  the POS Transactions report; charge → decline → transaction
  recorded, nothing else touched.
- Every `.py` file in `Source/` compiles cleanly.
