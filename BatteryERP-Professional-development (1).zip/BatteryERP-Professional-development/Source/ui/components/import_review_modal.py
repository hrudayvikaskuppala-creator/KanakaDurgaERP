"""
===========================================
 Import Review Modal
===========================================
Shared "pick a file -> extract -> review -> confirm" flow used by
the Supplier page, Product page, and the Purchase page's quick-add
popups. Always shows an editable copy of whatever was extracted (never
writes straight to the database) plus the raw extracted text, so the
user can fix anything the heuristics got wrong before it's applied.
"""

from tkinter import filedialog, messagebox
import customtkinter as ctk

from assets.themes import colors
from services.document_import_service import (
    extract_text_and_tables,
    parse_supplier_fields,
    parse_product_fields,
    SUPPORTED_EXTENSIONS,
    ImportError_
)

FIELD_LABELS = {
    "supplier": [
        ("supplier_name", "Supplier Name"),
        ("mobile", "Mobile"),
        ("gst_number", "GST Number"),
        ("email", "Email"),
        ("address", "Address"),
    ],
    "product": [
        ("brand", "Brand"),
        ("model", "Model"),
        ("capacity", "Capacity"),
        ("purchase_price", "Purchase Price"),
        ("selling_price", "Selling Price"),
        ("warranty", "Warranty (Months)"),
        ("rack_location", "Rack Location"),
    ],
}


def pick_file_and_review(parent, mode, on_confirm):
    """
    mode: "supplier" or "product".
    on_confirm(data: dict) is called with the (possibly edited)
    extracted fields once the user hits "Use This Data".
    """
    file_path = filedialog.askopenfilename(
        title="Import from File",
        filetypes=[
            ("Supported files", "*.pdf *.docx *.png *.jpg *.jpeg"),
            ("PDF files", "*.pdf"),
            ("Word documents", "*.docx"),
            ("Images", "*.png *.jpg *.jpeg"),
        ]
    )

    if not file_path:
        return

    try:
        text, _tables = extract_text_and_tables(file_path)
    except ImportError_ as exc:
        messagebox.showerror("Import Failed", str(exc), parent=parent)
        return
    except Exception as exc:
        messagebox.showerror(
            "Import Failed",
            f"Couldn't read this file.\n\nDetails: {exc}",
            parent=parent
        )
        return

    if not text.strip():
        messagebox.showwarning(
            "Nothing Found",
            "No readable text was found in this file. If it's a "
            "scanned document/photo, make sure it's clear and well-lit.",
            parent=parent
        )
        return

    parser = parse_supplier_fields if mode == "supplier" else parse_product_fields
    extracted = parser(text)

    _open_review_modal(parent, mode, extracted, text, on_confirm)


def _open_review_modal(parent, mode, extracted, raw_text, on_confirm):
    modal = ctk.CTkToplevel(parent)
    modal.title("Review Imported Data")
    modal.geometry("640x640")
    modal.grab_set()
    modal.transient(parent.winfo_toplevel())
    modal.configure(fg_color=colors.BACKGROUND)

    ctk.CTkLabel(
        modal, text="📄 Review Imported Data", font=colors.FONT_H2, text_color=colors.PRIMARY
    ).pack(pady=(16, 4))

    ctk.CTkLabel(
        modal,
        text="This was auto-extracted from your file - please check it's\ncorrect (and fill anything left blank) before using it.",
        font=colors.FONT_SMALL, text_color=colors.TEXT_LIGHT, justify="center"
    ).pack(pady=(0, 10))

    scroll = ctk.CTkScrollableFrame(modal, fg_color=colors.CARD, corner_radius=colors.RADIUS)
    scroll.pack(fill="both", expand=True, padx=20, pady=6)
    scroll.grid_columnconfigure(1, weight=1)

    entries = {}
    for row, (key, label) in enumerate(FIELD_LABELS[mode]):
        ctk.CTkLabel(scroll, text=label, font=colors.FONT_BODY_BOLD).grid(
            row=row, column=0, padx=12, pady=8, sticky="w"
        )
        entry = ctk.CTkEntry(scroll, width=380)
        entry.grid(row=row, column=1, padx=12, pady=8, sticky="ew")
        entry.insert(0, extracted.get(key, "") or "")
        entries[key] = entry

    with_raw_row = len(FIELD_LABELS[mode])
    ctk.CTkLabel(scroll, text="Raw extracted text", font=colors.FONT_BODY_BOLD).grid(
        row=with_raw_row, column=0, columnspan=2, padx=12, pady=(16, 4), sticky="w"
    )
    raw_box = ctk.CTkTextbox(scroll, width=560, height=140)
    raw_box.grid(row=with_raw_row + 1, column=0, columnspan=2, padx=12, pady=(0, 10), sticky="ew")
    raw_box.insert("1.0", raw_text.strip()[:4000])
    raw_box.configure(state="disabled")

    def confirm():
        data = {key: entry.get().strip() for key, entry in entries.items()}
        modal.destroy()
        on_confirm(data)

    button_row = ctk.CTkFrame(modal, fg_color="transparent")
    button_row.pack(pady=12)

    ctk.CTkButton(
        button_row, text="✅ Use This Data", fg_color=colors.SUCCESS,
        hover_color=colors.SUCCESS_HOVER, font=colors.FONT_BUTTON,
        width=180, command=confirm
    ).pack(side="left", padx=6)

    ctk.CTkButton(
        button_row, text="Cancel", fg_color=colors.SIDEBAR_BUTTON,
        font=colors.FONT_BUTTON, width=120, command=modal.destroy
    ).pack(side="left", padx=6)
