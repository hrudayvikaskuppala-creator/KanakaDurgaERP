from tkinter import filedialog, messagebox

from imports.parser import get_file_type, parse_product_data
from imports.pdf_import import extract_pdf
from imports.word_import import extract_word
from imports.excel_import import extract_excel
from imports.csv_import import extract_csv
from imports.image_import import extract_image

SUPPORTED_FILES = [
    (
        "All Supported Files",
        "*.pdf *.doc *.docx *.xls *.xlsx *.csv *.png *.jpg *.jpeg"
    ),
    ("PDF Files", "*.pdf"),
    ("Word Files", "*.doc *.docx"),
    ("Excel Files", "*.xls *.xlsx"),
    ("CSV Files", "*.csv"),
    ("Image Files", "*.png *.jpg *.jpeg")
]


def import_document():

    filename = filedialog.askopenfilename(
        title="Import Purchase Document",
        filetypes=SUPPORTED_FILES
    )

    if not filename:
        return

    extension = get_file_type(filename)

    text = ""

    try:

        if extension == ".pdf":
            text = extract_pdf(filename)

        elif extension in [".doc", ".docx"]:
            text = extract_word(filename)

        elif extension in [".xls", ".xlsx"]:
            text = extract_excel(filename)

        elif extension == ".csv":
            text = extract_csv(filename)

        elif extension in [".png", ".jpg", ".jpeg"]:
            text = extract_image(filename)

        else:
            messagebox.showwarning(
                "Unsupported File",
                f"{extension} is not supported."
            )
            return

        if not text.strip():
            messagebox.showwarning(
                "No Data Found",
                "No readable text was found in the selected file."
            )
            return

        product = parse_product_data(text)

        print("\n==========================")
        print("RAW IMPORTED TEXT")
        print("==========================")
        print(text)

        print("\n==========================")
        print("PARSED DATA")
        print("==========================")
        print(product)

        messagebox.showinfo(
            "Import Successful",
            "Document imported successfully.\n\nCheck the terminal for parsed data."
        )

        return product

    except Exception as e:

        messagebox.showerror(
            "Import Error",
            str(e)
        ) 