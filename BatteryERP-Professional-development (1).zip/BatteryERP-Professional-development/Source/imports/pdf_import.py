import pdfplumber


def extract_pdf(path):

    text = ""

    with pdfplumber.open(path) as pdf:

        for page in pdf.pages:

            data = page.extract_text()

            if data:

                text += data + "\n"

    return text