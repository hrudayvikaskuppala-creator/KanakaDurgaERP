import re


def parse_product_data(text: str):
    """
    Extract product details from imported text.
    """

    data = {
        "brand": "",
        "model": "",
        "capacity": "",
        "purchase_price": "",
        "selling_price": "",
        "warranty": "",
        "rack_location": "",
    }

    lines = [line.strip() for line in text.splitlines() if line.strip()]

    for line in lines:

        lower = line.lower()

        # Capacity
        match = re.search(r'(\d+\s?(ah|wh|mah))', lower)
        if match:
            data["capacity"] = match.group(1).upper()

        # Purchase Price
        if "purchase price" in lower or "cost" in lower:
            price = re.findall(r"\d+(?:\.\d+)?", line)
            if price:
                data["purchase_price"] = price[-1]

        # Selling Price
        if "selling price" in lower or "mrp" in lower:
            price = re.findall(r"\d+(?:\.\d+)?", line)
            if price:
                data["selling_price"] = price[-1]

        # Warranty
        if "warranty" in lower:
            months = re.findall(r"\d+", line)
            if months:
                data["warranty"] = months[0]

        # Rack
        if "rack" in lower:
            data["rack_location"] = line.split(":")[-1].strip()

        # Brand
        brands = [
            "Exide",
            "Amaron",
            "SF Sonic",
            "Livguard",
            "Luminous",
            "Tata Green",
            "Okaya"
        ]

        for b in brands:
            if b.lower() in lower:
                data["brand"] = b

        # Model
        if data["brand"]:
            if data["brand"].lower() in lower:
                data["model"] = line.replace(data["brand"], "").strip()

    return data